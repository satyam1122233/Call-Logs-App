package com.example.calllogs;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CallLog;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ImageView refresh;
    TextView lastSync;
    ArrayList<Model> arrayList = new ArrayList<>();
    RecyclerContactAdapter adapter;
    private static final int PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        refresh = findViewById(R.id.refresh);
        lastSync = findViewById(R.id.lastSync);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Check for permission and request it if not granted
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CALL_LOG}, PERMISSION_REQUEST_CODE);
        } else {
            // Permission is already granted, you can proceed to fetch the call logs
            fetchCallLogs();
        }

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check for permission and request it if not granted
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_CALL_LOG}, PERMISSION_REQUEST_CODE);
                } else {
                    // Permission is already granted, you can proceed to fetch the call logs
                    fetchCallLogs();
                }
            }
        });
    }

    // Handle permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, fetch the call logs
                fetchCallLogs();
            } else {
                // Permission denied, show a message to the user
                Toast.makeText(this, "Permission denied. Cannot access call logs.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Fetch call logs
    private void fetchCallLogs() {
        Uri uriCallLogs = Uri.parse("content://call_log/calls");
        Cursor cursorCallLogs = getContentResolver().query(uriCallLogs, null, null, null, null);

        if (cursorCallLogs != null) {
            arrayList.clear();

            while (cursorCallLogs.moveToNext()) {
                String number = cursorCallLogs.getString(cursorCallLogs.getColumnIndex(CallLog.Calls.NUMBER));
                String incompngTxt = cursorCallLogs.getString(cursorCallLogs.getColumnIndex(CallLog.Calls.TYPE));
                String date = cursorCallLogs.getString(cursorCallLogs.getColumnIndex(CallLog.Calls.DATE));

                String DurationTxt = cursorCallLogs.getString(cursorCallLogs.getColumnIndex(CallLog.Calls.DURATION));
                String fromTxt = cursorCallLogs.getString(cursorCallLogs.getColumnIndex(CallLog.Calls.NUMBER));

                String dateDuration = "Date: " +date + " | " + "Dur: "+ DurationTxt;

               lastSync.setText("Last Sync: "+date+" "+DurationTxt);
                arrayList.add(new Model(number, incompngTxt, dateDuration, fromTxt));
            }

            cursorCallLogs.close();

            // Initialize the adapter and set it on the RecyclerView
            adapter = new RecyclerContactAdapter( this, arrayList);
            RecyclerView recyclerView = findViewById(R.id.recyclerView);
            recyclerView.setAdapter(adapter);
        }
    }
}
