package com.example.calllogs;

public class Model {

    String numberTxt,incompngTxt,dateDurationTxt,fromTxt;

    public Model(String numberTxt,String incompngTxt,String dateDurationTxt,String fromTxt){

        this.numberTxt=numberTxt;
        this.incompngTxt=incompngTxt;
        this.dateDurationTxt=dateDurationTxt;
        this.fromTxt=fromTxt;
    }
}
